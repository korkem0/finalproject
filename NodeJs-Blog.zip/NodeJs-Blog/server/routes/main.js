const express = require('express');
const router = express.Router();
const Post = require('../models/Post'); 

// Routes

// Home Page Route with Pagination
router.get('/', async (req, res) => {
  try {
    const locals = {
        title: "NodeJS Blog",
        description: "Simple Blog created with NodeJS, Express & MongoDB.",
      };
    
      let perPage = 10; // Number of posts per page
      let page = req.query.page || 1; // Current page, default is 1
    
    const data = await Post.aggregate([{ $sort: { createdAt: -1 } } ])
      .skip((page - 1) * perPage) // Skip posts for previous pages
      .limit(perPage) // Limit to posts per page
      .exec();


     const count = await Post.count();
     const nextPage = parseInt(page) + 1; 
     const hasNextPage = nextPage <= Math.ceil(count / perpage); 

    res.render('index', { locals, data, current: page, nextPage: hasNextPage ? nextPage :null});
  } catch (error) {
    console.log( error);
  }
});

router.get('/post/:id', async (req, res) => {
    try {
        
        let slug = req.params.id; 
      const data = await Post.findById({ _id: slug}); // Fetch all posts from the database

      const locals = {
        title: data.title ,
        description: "Simple Blog created with NodeJS, Express & MongoDB.",
      };
      res.render('post', { locals, data }); // Render the index page with locals and data
    } catch (error) {
      console.log(error);
    
    }
  });
  
  router.post('/search', async (req, res) => {

    try {
      const locals = {
        title: "Search",
        description: "Simple Blog created with NodeJS, Express & MongoDB."
      }

      let searchTerm = req.body.searchTerm;
      console.log(searchTerm);

      //const data = await Post.find();
      res.send(searchTerm);
    } catch (error) {
      console.log(error);
    }
  });
  


// About Page Route
router.get('/about', (req, res) => {
  const locals = {
    title: "About Us",
    description: "Learn more about our NodeJS Blog project.",
  };

  res.render('about', { locals });
});

module.exports = router;
